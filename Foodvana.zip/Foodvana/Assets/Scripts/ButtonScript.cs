﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
//Thanks, Brackeys!

public class ButtonScript : MonoBehaviour {
    public void PlayGame ()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1); //Loads the Next Scene
    }

    public void QuitGame ()
    {
        Debug.Log("Quit!");
        Application.Quit(); //That should Quit things!
    }
}
