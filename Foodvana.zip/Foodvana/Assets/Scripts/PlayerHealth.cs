﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

//This class is used to keep track of player health
//Thanks Unity Tutorials!
//Written by Kraken

public class PlayerHealth : MonoBehaviour {

    //Beginning health is 100, same width as the image. 
    public int startingHealth = 100;
    public int currentHealth; //To track current health



	// Use this for initialization
	void Awake () {
        currentHealth = startingHealth; // Both at 100. Now, what could change that?



	}

    public void Hurt(int damage) //Called by enemies. That's mean!
    {
        Debug.Log("Ouch!");
        currentHealth = currentHealth - damage;
        if (currentHealth <= 0)
        {
            Death();
        }
    }

    public void Death() //You dead. 
    {
        Debug.Log("You Dead");
        //Disable Unit
        gameObject.SetActive(false);


    }
	
	// Update is called once per frame
	void Update () {
        //Set length of healthbar to currenthealth.
       /* Gameobject healthBar = GameObject.Find("Canvas/HealthBar");
        var healthBarRectTransform = healthBar.transform as RectTransform;
        healthBarRectTransform.width = currentHealth;*/
        //Hope this works

	}
}
